// let x, y, z;
// x = 5;
// y = 5;
// z = x + y;
// document.getElementById("demo1").innerHTML = z ;

function multiplyBy() {
    num1 = document.getElementById(
        "input first_value").value;
    num2 = document.getElementById(
        "input second_value").value;
    num3= document.getElementById(
        "input third_value").innerHTML = num1 * num2;
}

function dividedBy() {
    num1 = document.getElementById(
        "input first_value").value;
    num2 = document.getElementById(
        "input second_value").value;
    num3= document.getElementById(
        "input third_value").innerHTML = num1 / num2;
}

function subtractBy() {
    num1 = document.getElementById(
        "input first_value").value;
    num2 = document.getElementById(
        "input second_value").value;
    num3= document.getElementById(
        "input third_value").innerHTML = num1 - num2;
}

function additionBy() {
    num1 = document.getElementById(
        "input first_value").value;
    num2 = document.getElementById(
        "input second_value").value;
    num3= document.getElementById(
        "input third_value").innerHTML = num1 + num2;
}